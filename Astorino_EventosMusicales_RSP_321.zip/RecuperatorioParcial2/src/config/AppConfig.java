package config;

public class AppConfig {
    public static final String PATH_FILES = "src/data/";
    public static final String PATH_CSV = PATH_FILES + "EventosMusicales.csv";    
    public static final String PATH_SER = PATH_FILES + "EventosMusicales.dat";
}
