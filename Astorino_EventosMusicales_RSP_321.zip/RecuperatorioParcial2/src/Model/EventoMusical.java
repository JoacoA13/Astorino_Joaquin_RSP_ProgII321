
package Model;

import Service.CSVSerializable;
import java.time.LocalDate;


public class EventoMusical extends Evento implements CSVSerializable, Comparable<EventoMusical>{
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    @Override
    public String toString() {
        return "EventoMusical{" + "id=" + super.getId() + ", " + "nombre='" + super.getNombre() + "', " + "fecha=" + super.getFecha() + ", " + "artista='" + artista + "', " + "genero=" + genero + '}';
    }

    
    @Override
    public int compareTo(EventoMusical o) {
        return this.getFecha().compareTo(o.getFecha());
    }
        
    @Override
    public String toCSV() {
        return String.format("%d,%s,%s,%s,%s", super.getId(), super.getNombre(), super.getFecha().toString(), artista, genero);
    }

    @Override
    public String toHeaderCSV() {
        return "id,nombre,fecha,artista,genero" + "\n";
    }
    
    public static EventoMusical fromCSV(String csv) {
        String[] values = csv.split(",");
        return new EventoMusical(Integer.parseInt(values[0]),values[1],LocalDate.parse(values[2]),values[3],GeneroMusical.valueOf(values[4]));
    }

}
