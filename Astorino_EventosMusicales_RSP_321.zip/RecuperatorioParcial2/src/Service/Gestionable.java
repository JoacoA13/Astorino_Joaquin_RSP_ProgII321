package Service;

import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public interface Gestionable<T extends CSVSerializable & Comparable<T>> {
    void agregar(T item);
    
    T obtener(int indice);
    
    T eliminar(int indice);
    
    void limpiarElementos();
    
    int tamanio();
    
    void ordenar();
    
    void ordenar(Comparator<T> comparator);
    
    List<T> filtrar(Predicate<T> predicate);
    
    void paraCadaElemento(Consumer<T> consumer);
    
    void mostrarTodos();
}
