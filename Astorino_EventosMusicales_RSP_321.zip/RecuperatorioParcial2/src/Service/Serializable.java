package Service;

import java.io.IOException;

public interface Serializable<T extends CSVSerializable> {
    void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException;
            
    void guardarEnBinario(String path) throws IOException;
}
