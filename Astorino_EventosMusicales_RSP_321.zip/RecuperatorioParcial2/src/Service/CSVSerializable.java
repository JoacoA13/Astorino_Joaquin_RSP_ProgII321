package Service;

public interface CSVSerializable {
    String toCSV();
    
    String toHeaderCSV();
}
