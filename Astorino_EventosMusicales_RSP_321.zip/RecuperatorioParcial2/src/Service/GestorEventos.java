package Service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class GestorEventos<T extends CSVSerializable & Comparable<T>> implements Gestionable<T>, Serializable<T>, Archivable<T> {

    List<T> items = new ArrayList<>();

    @Override
    public void agregar(T item) {
        checkItem(item);
        items.add(item);
    }

    @Override
    public T obtener(int indice) {
        checkIndice(indice);
        return items.get(indice);
    }

    @Override
    public T eliminar(int indice) {
        checkIndice(indice);
        return items.remove(indice);
    }

    @Override
    public void limpiarElementos() {
        items.clear();
    }

    @Override
    public List<T> filtrar(Predicate<T> predicate) {
        List<T> toReturn = new ArrayList<>();
        for (T item : items) {
            if (predicate.test(item)) {
                toReturn.add(item);
            }
        }
        return toReturn;
    }

    @Override
    public void ordenar() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparator) {
        items.sort(comparator);
    }

    @Override
    public void paraCadaElemento(Consumer<T> consumer) {
        validarListaVacia();
        for (T item : items) {
            consumer.accept(item);
        }
    }

    @Override
    public void mostrarTodos() {
        paraCadaElemento(System.out::println);
    }

    @Override
    public void guardarEnCSV(String path) throws IOException {
        validarListaVacia();
        checkPath(path);
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write(items.get(0).toHeaderCSV());
            for (T item : items) {
                bw.write(item.toCSV() + "\n");
            }
        }
    }

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> transformadora) throws IOException {
        checkPath(path);
        checkFileExiste(path);
        items.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String linea = "";
            br.readLine();
            while ((linea = br.readLine()) != null) {
                items.add(transformadora.apply(linea));
            }
        }
    }

    @Override
    public void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException {
        checkPath(path);
        checkFileExiste(path);
        items.clear();

        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            items.addAll((List<T>) entrada.readObject());
        }
    }

    @Override
    public void guardarEnBinario(String path) throws IOException {
        validarListaVacia();
        checkPath(path);
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(items);
        }
    }

    private void checkItem(T item) {
        if (item == null) {
            throw new IllegalArgumentException("No se puede almacenar algo nulo");
        }
    }

    @Override
    public int tamanio() {
        return items.size();
    }

    private void checkIndice(int indice) {
        if (indice < 0 || indice >= tamanio()) {
            throw new IndexOutOfBoundsException("El elemento es menor a 0 o es mayor al tamanio del indice");
        }
    }

    private void checkPath(String path) {
        if (path == null) {
            throw new IllegalArgumentException("El path no puede ser nulo");
        }
    }

    private void checkFileExiste(String path) {
        File archivo = new File(path);
        if (!archivo.exists()) {
            throw new IllegalArgumentException("El archivo no existe en la ruta: " + path);
        }
    }

    private void validarListaVacia() {
        if (items.isEmpty()) {
            throw new IllegalStateException("La lista no puede estar vacia");
        }
    }

}
