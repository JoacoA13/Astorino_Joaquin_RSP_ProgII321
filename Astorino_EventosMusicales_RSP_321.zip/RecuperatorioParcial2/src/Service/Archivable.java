package Service;

import java.io.IOException;
import java.util.function.Function;

public interface Archivable<T> {
    void guardarEnCSV(String path) throws IOException;
            
    void cargarDesdeCSV(String path, Function<String, T> transformadora) throws IOException;
    
}
